# Dear Letters — implementation plan

## Product direction
A private vintage writing room: a sunset-lit antique desk, locked letter chest, envelope-based collection, tactile letter opening, and a calm single-track music player.

## Design
- **Movement:** nostalgic cinematic editorial / antique study.
- **Principles:** warmth before polish, tactile paper-and-brass details, restrained contrast, motion that feels physical.
- **Palette:** walnut brown, candle gold, faded paper, terracotta wax, moss green.
- **Layout:** the hero is composed as a room rather than a dashboard; the desk anchors the experience and the letter chest sits in the physical middle of the scene.
- **Signature elements:** brass lock chest, floating dust/candle flicker, envelopes as the collection UI.
- **Typography:** Cormorant Garamond for letter-like display text; DM Sans for small utility labels.
- **Brand essence:** a private place to keep the words that matter; warm, intimate, nostalgic.

## Implementation
- React/Vite frontend in `client/src`.
- The supplied antique-study image is used as the immersive background asset.
- Client-side demo persistence uses localStorage for letters while the initialized project keeps server/database capabilities enabled for the next auth/storage pass.
- Responsive layout supports desktop and mobile widths.
- `/manus-routes.json` declares the root route.

import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BookOpen, ChevronLeft, ChevronRight, Feather, Heart, LockKeyhole, Mail, Music2, Pause, Pencil, Play, Plus, Quote, Sparkles, Volume2, X } from "lucide-react";

type Letter = { id: number; title: string; to: string; date: string; excerpt: string; body: string; color: string; };

const seedLetters: Letter[] = [
  { id: 1, title: "For the evenings we keep", to: "to someone dear", date: "Oct 12, 1997", excerpt: "There are some evenings that deserve to be folded carefully…", body: "There are some evenings that deserve to be folded carefully and tucked away, like a pressed flower between the pages of a book.\n\nI hope you remember this one—the light on the water, the quiet between our sentences, and the way the whole room seemed to breathe with us.\n\nUntil the next letter,\nAlways yours", color: "#bb7356" },
  { id: 2, title: "A small promise", to: "to my future self", date: "Sep 03, 1997", excerpt: "If you are reading this, you made it through another season…", body: "If you are reading this, you made it through another season. I knew you would.\n\nKeep the soft parts of yourself. They are not a weakness. They are the reason you notice the first star, the last song, and the warmth in a stranger's hello.\n\nWith patience,\nMe", color: "#7e9a88" },
  { id: 3, title: "The song on the radio", to: "to an old friend", date: "Aug 21, 1997", excerpt: "It played again today, and for a moment the years felt very close…", body: "It played again today, and for a moment the years felt very close.\n\nFunny how a melody can keep a room exactly as it was. Your laugh by the window, the tea going cold, our plans written in the margins.\n\nWrite back when you can.\nYours, as ever", color: "#b29b68" },
];

export default function Home() {
  const [letters, setLetters] = useState<Letter[]>(() => {
    try { return JSON.parse(localStorage.getItem("dear-letters") || "null") || seedLetters; } catch { return seedLetters; }
  });
  const [unlocked, setUnlocked] = useState(false);
  const [password, setPassword] = useState("");
  const [unlockError, setUnlockError] = useState(false);
  const [selected, setSelected] = useState<Letter | null>(null);
  const [writing, setWriting] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [newLetter, setNewLetter] = useState({ title: "", to: "", body: "" });
  const [accessOpen, setAccessOpen] = useState(false);
  const [accessMode, setAccessMode] = useState<"create" | "unlock">(() => localStorage.getItem("dear-letters-password") ? "unlock" : "create");
  const [accessPassword, setAccessPassword] = useState("");
  const [accessConfirm, setAccessConfirm] = useState("");
  const [accessMessage, setAccessMessage] = useState("");

  useEffect(() => { localStorage.setItem("dear-letters", JSON.stringify(letters)); }, [letters]);
  const totalWords = useMemo(() => letters.reduce((sum, l) => sum + l.body.split(/\s+/).length, 0), [letters]);

  const unlock = () => {
    if (password.trim().length >= 4) { setUnlocked(true); setUnlockError(false); }
    else setUnlockError(true);
  };
  const openChest = () => {
    setAccessMode(localStorage.getItem("dear-letters-password") ? "unlock" : "create");
    setAccessPassword(""); setAccessConfirm(""); setAccessMessage(""); setAccessOpen(true);
  };
  const submitAccess = () => {
    if (accessPassword.trim().length < 4) { setAccessMessage("Choose at least 4 characters."); return; }
    if (accessMode === "create") {
      if (accessPassword !== accessConfirm) { setAccessMessage("The two passwords do not match."); return; }
      localStorage.setItem("dear-letters-password", accessPassword);
    } else if (accessPassword !== localStorage.getItem("dear-letters-password")) { setAccessMessage("That password does not open this chest."); return; }
    setUnlocked(true); setAccessOpen(false); setAccessMessage("");
  };
  const saveLetter = () => {
    if (!newLetter.title.trim() || !newLetter.body.trim()) return;
    const letter: Letter = { id: Date.now(), title: newLetter.title, to: newLetter.to || "to someone dear", date: "Just now", excerpt: newLetter.body.slice(0, 72) + "…", body: newLetter.body, color: "#b88363" };
    setLetters((prev) => [letter, ...prev]); setWriting(false); setNewLetter({ title: "", to: "", body: "" });
  };

  return (
    <main className={`room-shell ${unlocked ? "room-unlocked" : ""}`}>
      <div className="scene-bg" />
      <div className="scene-vignette" />
      <div className="dust dust-a" /><div className="dust dust-b" /><div className="dust dust-c" />
      <header className="topbar">
        <div className="brand"><span className="brand-mark"><Feather size={16} /></span><span>Dear Letters</span><span className="brand-divider" /><span className="brand-sub">a private writing room</span></div>
        <nav><button className="nav-active">My letters <span>{letters.length}</span></button><button onClick={() => setWriting(true)}>New letter</button><button onClick={() => setUnlocked(false)}>{unlocked ? "Lock chest" : "Sign in"} <span className="avatar">Z</span></button></nav>
      </header>

      <section className="hero-copy"><p className="eyebrow"><Sparkles size={12} /> dusk, 7:42 pm</p><h1>A place to write,<br /><em>a space to remember.</em></h1><p className="hero-note">Some words are meant to be kept close.</p></section>

      <div className="desk-scene">
        <div className="lamp-glow" />
        <div className="curtain-sway curtain-left" /><div className="curtain-sway curtain-right" /><div className="leaf-drift leaf-one">✦</div><div className="leaf-drift leaf-two">❧</div><div className="water-shimmer" />
        <div className="candle"><div className="flame" /><div className="wax" /></div>
        <div className="desk-paper paper-back" /><div className="desk-paper paper-front" />
        <div className="inkwell"><div className="ink-shine" /></div><div className="quill"><Feather size={62} strokeWidth={1.3} /></div>
        <motion.div className={`chest ${unlocked ? "chest-open" : ""}`} onClick={openChest} role="button" tabIndex={0} aria-label="Open your letter chest" onKeyDown={e => e.key === "Enter" && openChest()}>
          <div className="chest-lid"><div className="lid-band" /></div><div className="chest-body"><div className="chest-plaque"><LockKeyhole size={17} /><span>MY LETTERS</span></div><div className="chest-corner corner-l" /><div className="chest-corner corner-r" /><div className="brass-keyhole"><LockKeyhole size={13} /></div></div>
          {!unlocked && <div className="lock-chip"><LockKeyhole size={13} /> click to open</div>}
          {unlocked && <div className="envelope-peek"><Mail size={15} /></div>}
        </motion.div>
        <div className="desk-caption">a little room for the things<br />we don't want to forget</div>
      </div>

      <section className="lower-panel">
        <div className="panel-heading"><div><p className="eyebrow">the letter chest</p><h2>{unlocked ? "Your kept words" : "A quiet place for your words"}</h2></div><div className="panel-actions"><span className="word-count">{unlocked ? `${letters.length} letters · ${totalWords} words` : "private by design"}</span>{unlocked && <button className="gold-button" onClick={() => setWriting(true)}><Plus size={15} /> write a letter</button>}</div></div>
        {!unlocked ? (
          <div className="unlock-card"><div className="wax-seal"><Heart size={19} fill="currentColor" /></div><div><h3>Your letters are waiting in the chest.</h3><p>Click the antique box on the desk to create your key or open your private room. The box is the only doorway.</p></div><button className="gold-button" onClick={openChest}><LockKeyhole size={14} /> click the box</button></div>
        ) : (
          <div className="letter-grid">{letters.map((letter, i) => <motion.button className="letter-card" key={letter.id} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * .08 }} onClick={() => setSelected(letter)}><div className="envelope-visual" style={{ "--envelope": letter.color } as any}><div className="envelope-flap" /><div className="envelope-paper"><Mail size={20} /></div><span>{String(i + 1).padStart(2, "0")}</span></div><div className="letter-meta"><span>{letter.date}</span><h3>{letter.title}</h3><p>{letter.excerpt}</p><small>{letter.to}</small></div></motion.button>)}</div>
        )}
      </section>

      <footer className="music-player"><div className="record"><div className="record-label">DL</div></div><div className="track"><span className="eyebrow">now playing</span><strong>Ab Kisko Kahoon Humdum</strong><small>Kishore Kumar · 1990s memory</small></div><div className="music-controls"><button onClick={() => setIsPlaying(!isPlaying)} aria-label="play pause">{isPlaying ? <Pause size={17} /> : <Play size={17} fill="currentColor" />}</button><div className="waveform">{[10,18,13,22,16,26,12,20,15,24,11,17,9].map((h, i) => <i key={i} style={{ height: h, animationDelay: `${i * .08}s` }} className={isPlaying ? "wave-on" : ""} />)}</div><button onClick={() => setIsMuted(!isMuted)}><Volume2 size={16} /></button></div></footer>

      <AnimatePresence>{accessOpen && <AccessModal mode={accessMode} password={accessPassword} confirm={accessConfirm} message={accessMessage} setPassword={setAccessPassword} setConfirm={setAccessConfirm} onClose={() => setAccessOpen(false)} onSubmit={submitAccess} />}</AnimatePresence>
      <AnimatePresence>{selected && <LetterModal letter={selected} onClose={() => setSelected(null)} />}</AnimatePresence>
      <AnimatePresence>{writing && <WriteModal value={newLetter} setValue={setNewLetter} onClose={() => setWriting(false)} onSave={saveLetter} />}</AnimatePresence>
    </main>
  );
}

function LetterModal({ letter, onClose }: { letter: Letter; onClose: () => void }) { return <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><motion.article className="letter-modal" initial={{ y: 45, rotate: 1.5, opacity: 0 }} animate={{ y: 0, rotate: 0, opacity: 1 }} exit={{ y: 25, opacity: 0 }}><button className="close-modal" onClick={onClose}><X size={17} /></button><div className="letter-header"><span className="eyebrow">{letter.date}</span><h2>{letter.title}</h2><p>{letter.to}</p></div><div className="paper-rule" /><div className="letter-body">{letter.body.split("\n").map((line, i) => <p key={i}>{line || "\u00A0"}</p>)}</div><div className="letter-footer"><Quote size={18} /><span>kept safely in your chest</span><ChevronLeft size={15} /><ChevronRight size={15} /></div></motion.article></motion.div> }
function WriteModal({ value, setValue, onClose, onSave }: { value: { title: string; to: string; body: string }; setValue: (v: { title: string; to: string; body: string }) => void; onClose: () => void; onSave: () => void }) { return <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><motion.article className="write-modal" initial={{ y: 35, opacity: 0 }} animate={{ y: 0, opacity: 1 }}><button className="close-modal" onClick={onClose}><X size={17} /></button><div className="write-top"><div><span className="eyebrow">a fresh page</span><h2>Write it down.</h2></div><Pencil size={22} /></div><input className="write-input title-input" value={value.title} onChange={e => setValue({ ...value, title: e.target.value })} placeholder="give this letter a little title" /><input className="write-input" value={value.to} onChange={e => setValue({ ...value, to: e.target.value })} placeholder="to…" /><textarea className="write-area" value={value.body} onChange={e => setValue({ ...value, body: e.target.value })} placeholder="Dear…\n\nWrite what you want to remember." /><div className="write-actions"><span><BookOpen size={14} /> saved privately to your chest</span><button className="gold-button" onClick={onSave}>seal letter <Mail size={14} /></button></div></motion.article></motion.div> }

function AccessModal({ mode, password, confirm, message, setPassword, setConfirm, onClose, onSubmit }: { mode: "create" | "unlock"; password: string; confirm: string; message: string; setPassword: (v: string) => void; setConfirm: (v: string) => void; onClose: () => void; onSubmit: () => void }) {
  return <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><motion.article className="access-modal" initial={{ y: 22, scale: .97, opacity: 0 }} animate={{ y: 0, scale: 1, opacity: 1 }}><button className="close-modal" onClick={onClose}><X size={17} /></button><div className="wax-seal access-seal"><Heart size={19} fill="currentColor" /></div><span className="eyebrow">{mode === "create" ? "your private room" : "the letter chest"}</span><h2>{mode === "create" ? "Choose a password." : "Your letters are waiting."}</h2><p>{mode === "create" ? "This is the only time we will ask you to make one. Keep it somewhere safe; it is the key to every letter in this room." : "Enter the password you chose when you first made this room."}</p><div className="access-fields"><input autoFocus type="password" value={password} onChange={e => setPassword(e.target.value)} onKeyDown={e => e.key === "Enter" && onSubmit()} placeholder={mode === "create" ? "create a password" : "your password"} />{mode === "create" && <input type="password" value={confirm} onChange={e => setConfirm(e.target.value)} onKeyDown={e => e.key === "Enter" && onSubmit()} placeholder="repeat it once" />}</div>{message && <small className="access-message">{message}</small>}<button className="gold-button access-submit" onClick={onSubmit}>{mode === "create" ? "make my letter room" : "open the chest"} <ChevronRight size={15} /></button></motion.article></motion.div>;
}

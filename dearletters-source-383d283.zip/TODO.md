# Dear Letters TODO

- [x] **Create the realistic vintage writing-room interface.** The site has a sunset atmosphere, antique desk, warm lamplight, textured wood, brass details, nostalgic 1990s mood, responsive layout, and accessible interaction states.
- [x] **Create the locked letter chest entry flow.** Visitors can enter a passphrase and unlock the personal letter collection; invalid short passphrases show an inline error.
- [x] **Create the envelope-based collection view.** Saved letters appear as physical envelope cards with dates, recipients, excerpts, and an opening interaction.
- [x] **Create the readable letter view.** Clicking an envelope opens a paper-styled modal with animated presentation, readable body copy, and close controls.
- [x] **Create the writing mode.** Users can compose a title, recipient, and body on a desk-paper writing surface and save the result back to the chest.
- [x] **Add persistent demo storage.** Saved letters persist in localStorage between visits in the current prototype.
- [x] **Add the single-track nostalgic music player UI.** The player shows “Ab Kisko Kahoon Humdum — Kishore Kumar” with play/pause, mute, and animated waveform controls.
- [ ] **Connect account auth, password hashing, sharing permissions, and server-backed letter storage.** The project is initialized with server and database capabilities so this can be added without changing the visual flow.
